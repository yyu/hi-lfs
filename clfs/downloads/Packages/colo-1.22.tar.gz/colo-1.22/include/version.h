/*
 * (C) P.Horton 2004,2005,2006
 *
 * $Id: version.h 194 2006-08-10 20:02:19Z pdh $
 *
 * This code is covered by the GNU General Public License. For details see the file "COPYING".
 */

#ifndef _VERSION_H_
#define _VERSION_H_

#define VER_MAJOR					1
#define VER_MINOR					22

#endif

/* vi:set ts=3 sw=3 cin path=include,../include: */
