/*
 * (C) P.Horton 2004,2005,2006
 *
 * $Id: lib.h 186 2006-01-17 23:03:58Z pdh $
 *
 * This code is covered by the GNU General Public License. For details see the file "COPYING".
 */

#ifndef _LIB_H_
#define _LIB_H_

#include <string.h>

typedef unsigned	UWORD32;

#endif

/* vi:set ts=3 sw=3 cin: */
