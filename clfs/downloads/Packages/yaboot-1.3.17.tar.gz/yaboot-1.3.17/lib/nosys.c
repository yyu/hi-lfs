/* we got no time */
long time()
{
    return 0;
}
